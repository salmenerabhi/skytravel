#include <gtk/gtk.h>




typedef struct 
{
int jour;
int mois;
int annee;
}date;



typedef struct 
{
char expediteur[20];
date dt_rec ;
char objet[20];
char sujet[20];
}reclam;


void ajoute( reclam s);


int supprimer(char objetreclam[]);
int modifier( reclam s);

void afficher_reclamation (GtkWidget *liste);
