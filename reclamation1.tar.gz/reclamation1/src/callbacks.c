#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclamation.h"


void
on_envoyer_reclamation_NABIL_clicked   (GtkWidget *objet_graphique,gpointer user_data)
{
GtkWidget *window1;
GtkWidget *expediteur,*objet,*sujet,*jour,*mois,*annee;

reclam s;
date dt_rec;

expediteur=lookup_widget(objet_graphique,"entry1");
jour=lookup_widget(objet_graphique, "spinbutton1");
mois=lookup_widget(objet_graphique, "spinbutton2");
annee=lookup_widget(objet_graphique, "spinbutton3");

objet=lookup_widget(objet_graphique,"entry2");
sujet=lookup_widget(objet_graphique,"entry3");
window1=lookup_widget(objet_graphique,"window1");
s.dt_rec.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
s.dt_rec.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
s.dt_rec.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
strcpy(s.expediteur,gtk_entry_get_text(GTK_ENTRY(expediteur)));
strcpy(s.objet,gtk_entry_get_text(GTK_ENTRY(objet)));
strcpy(s.sujet,gtk_entry_get_text(GTK_ENTRY(sujet)));


ajoute (s);
}


void
on_afficher_reclamtion_NABIL_clicked   (GtkWidget *objet_graphique,gpointer user_data)
{
GtkWidget *listview;
listview=lookup_widget(objet_graphique,"treeview1");
afficher_reclamation(listview);
}


void
on_supprimer_reclamation_NABIL_clicked (GtkWidget *objet_graphique,gpointer user_data)
{
GtkWidget *xx; 
	int acc;
	char xxx[20];
	xx=lookup_widget(objet_graphique, "entry4");
	strcpy(xxx,gtk_entry_get_text(GTK_ENTRY(xx)));
	acc=supprimer(xxx);

}



void
on_button1_nabil_clicked               (GtkWidget *objet_graphique,gpointer user_data)
{
char login[30];
GtkWidget *verif,*output1,*output2;
output1=lookup_widget(objet_graphique,"label12");
output2=lookup_widget(objet_graphique,"label13");

verif=lookup_widget(objet_graphique, "entry5");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(verif)));

reclam s;
FILE*f;
f=fopen("src/reclamation.txt","r");
if (f!=NULL)
{
while(fscanf(f,"%s %d %d %d %s %s \n",s.expediteur,&s.dt_rec.jour,&s.dt_rec.mois,&s.dt_rec.annee,s.objet,s.sujet)!=EOF)
{
if(strcmp(login,s.expediteur)==0)
{
gtk_label_set_text(GTK_LABEL(output1),s.objet);
gtk_label_set_text(GTK_LABEL(output2),s.sujet);


}
}
}
}


void
on_modifier_nabil_clicked              (GtkWidget *objet_graphique,gpointer user_data)
{
GtkWidget *window1;
GtkWidget *expediteur,*objet,*sujet,*jour,*mois,*annee;

reclam s;
date dt_rec;
expediteur=lookup_widget(objet_graphique,"entry5");
objet=lookup_widget(objet_graphique,"entry6");
sujet=lookup_widget(objet_graphique,"entry7");
jour=lookup_widget(objet_graphique, "spinbutton4");
mois=lookup_widget(objet_graphique, "spinbutton5");
annee=lookup_widget(objet_graphique, "spinbutton6");

s.dt_rec.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
s.dt_rec.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
s.dt_rec.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
strcpy(s.expediteur,gtk_entry_get_text(GTK_ENTRY(expediteur)));
strcpy(s.objet,gtk_entry_get_text(GTK_ENTRY(objet)));
strcpy(s.sujet,gtk_entry_get_text(GTK_ENTRY(sujet)));


modifier (s);
}

