#include <gtk/gtk.h>


void
on_envoyer_reclamation_NABIL_clicked   (GtkWidget *objet_graphique,gpointer user_data);

void
on_afficher_reclamtion_NABIL_clicked   (GtkWidget *objet_graphique,gpointer user_data);

void
on_supprimer_reclamation_NABIL_clicked (GtkWidget *objet_graphique,gpointer user_data);

void
on_recherche_reclamation_NABIL_clicked (GtkWidget *objet_graphique,gpointer user_data);





void
on_button1_nabil_clicked               (GtkWidget *objet_graphique,gpointer user_data);

void
on_modifier_nabil_clicked              (GtkWidget *objet_graphique,gpointer user_data);
