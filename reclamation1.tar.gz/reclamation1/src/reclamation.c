
#include<string.h>
#include<stdio.h>
#include<stdlib.h>

#include "reclamation.h"


///////////////////////////

void ajoute (reclam s)
{
FILE*f;

f=fopen("/home/nabil/Bureau/reclamation1/src/reclamation.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %d %d %d %s %s \n",s.expediteur,s.dt_rec.jour,s.dt_rec.mois,s.dt_rec.annee,s.objet,s.sujet);

fclose(f);
}


}
////////////////////////////////////////////////
int supprimer(char expediteurreclam[])
{
reclam s;
FILE*f;
FILE*f1;
int test=-1;
f=fopen("/home/nabil/Bureau/reclamation1/src/reclamation.txt","r");
f1=fopen("/home/nabil/Bureau/reclamation1/src/fichier.txt","a+");
while(fscanf(f,"%s %d %d %d %s %s \n",s.expediteur,&s.dt_rec.jour,&s.dt_rec.mois,&s.dt_rec.annee,s.objet,s.sujet)!=EOF)
{
if(strcmp(expediteurreclam,s.expediteur)!=0)
{
fprintf(f1,"%s %d %d %d %s %s \n",s.expediteur,s.dt_rec.jour,s.dt_rec.mois,s.dt_rec.annee,s.objet,s.sujet);
}
else
{
test=1;
}
}
fclose(f);
fclose(f1);
remove("/home/nabil/Bureau/reclamation1/src/reclamation.txt");
rename("/home/nabil/Bureau/reclamation1/src/fichier.txt","/home/nabil/Bureau/reclamation1/src/reclamation.txt");
return(test);
} 
//////////////////////////////////////////////////////////////////
int modifier (reclam s)
{
reclam s1 ;
int retour=-1;
FILE*f;
FILE*f1;
f=fopen("/home/nabil/Bureau/reclamation1/src/reclamation.txt","r");
f1=fopen("/home/nabil/Bureau/reclamation1/src/fichier.txt","a+");
while(fscanf(f,"%s %d %d %d %s %s \n",s1.expediteur,&s1.dt_rec.jour,&s1.dt_rec.mois,&s1.dt_rec.annee,s1.objet,s1.sujet)!=EOF)
{
if(strcmp(s1.expediteur,s1.expediteur)==0)
{
fprintf(f1,"%s %d %d %d %s %s \n",s.expediteur,s.dt_rec.jour,s.dt_rec.mois,s.dt_rec.annee,s.objet,s.sujet);
retour=1;
}
else
{
fprintf(f1,"%s %d %d %d %s %s \n",s1.expediteur,s1.dt_rec.jour,s1.dt_rec.mois,s1.dt_rec.annee,s1.objet,s1.sujet);
}
}
  fclose(f);
  fclose(f1);
  remove("/home/nabil/Bureau/reclamation1/src/reclamation.txt");
  rename("/home/nabil/Bureau/reclamation1/src/fichier.txt","/home/nabil/Bureau/reclamation1/src/reclamation.txt");
return(retour);
}
////////////////////////////////
void afficher_reclamation(GtkWidget *liste)
{
enum   
{       
        expediteur,
        objet,
	sujet,
        COLUMNS
};

        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	int i ;
	
        reclam s ;
        
        store=NULL;

        FILE *f;
	
	store =gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" expediteur", renderer, "text",expediteur, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" objet", renderer, "text",objet, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" sujet", renderer, "text",sujet, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("/home/nabil/Bureau/reclamation1/src/reclamation.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("/home/nabil/Bureau/reclamation1/src/reclamation.txt", "a+");
             while(fscanf(f,"%s %d %d %d %s %s \n",s.expediteur,&s.dt_rec.jour,&s.dt_rec.mois,&s.dt_rec.annee,s.objet,s.sujet)!=EOF)


{
		
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, expediteur, s.expediteur, objet, s.objet, sujet, s.sujet, -1); 
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
      }
/////////////////////////////


