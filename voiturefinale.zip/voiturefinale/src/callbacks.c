
#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "voiture.h" 


void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *fenetre_ajout;

window1=lookup_widget(objet,"window1");
gtk_widget_destroy(window1);

fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
fenetre_ajout=create_fenetre_ajout();
gtk_widget_show(fenetre_ajout);
}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *fenetre_modifier;

window1=lookup_widget(objet,"window1");
gtk_widget_destroy(window1);

fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
fenetre_modifier=create_fenetre_modifier();
gtk_widget_show(fenetre_modifier);

}


void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *fenetre_supprimer;

window1=lookup_widget(objet,"window1");
gtk_widget_destroy(window1);

fenetre_supprimer=lookup_widget(objet,"fenetre_supprimer");
fenetre_supprimer=create_fenetre_supprimer();
gtk_widget_show(fenetre_supprimer);

}


void
on_Valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget* ajout ;
Voiture V;
GtkWidget *output ;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *fenetre_ajout;

fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
output=lookup_widget(objet,"labelMsg");
input1=lookup_widget(objet,"entrycode1");
input2=lookup_widget(objet,"entrymarque");
input3=lookup_widget(objet,"entrydateprise");
input4=lookup_widget(objet,"entryH");
input5=lookup_widget(objet,"entrydaterest");
input6=lookup_widget(objet,"entryHe");
input7=lookup_widget(objet,"entryprix");
strcpy(V.code,gtk_entry_get_text(GTK_ENTRY (input1)));
strcpy(V.marque,gtk_entry_get_text(GTK_ENTRY (input2)));
strcpy(V.date_prise,gtk_entry_get_text(GTK_ENTRY (input3)));
strcpy(V.heure,gtk_entry_get_text(GTK_ENTRY (input4)));
strcpy(V.date_rest,gtk_entry_get_text(GTK_ENTRY (input5)));
strcpy(V.heure1,gtk_entry_get_text(GTK_ENTRY (input6)));
strcpy(V.prix,gtk_entry_get_text(GTK_ENTRY (input7)));


ajouter_voiture(V);
ajout=create_ajout();
gtk_widget_show(ajout);

}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1,  *fenetre_ajout, *treeview1;
fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
gtk_widget_destroy(fenetre_ajout);
window1=create_window1();
gtk_widget_show(window1);
treeview1=lookup_widget(window1,"treeview1");
afficher_voiture(treeview1);

}


void
on_listevoitures_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window0;
GtkWidget *window1;
GtkWidget *treeview1;

window0=lookup_widget(objet,"window0");
gtk_widget_destroy(window0);

window1=lookup_widget(objet,"window1");
window1=create_window1();
gtk_widget_show(window1);

treeview1=lookup_widget(window1,"treeview1");
afficher_voiture(treeview1);
}


void
on_quitter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window0 ;
window0=lookup_widget(objet,"window0");
gtk_widget_destroy(window0);

}


void
on_valider1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget* modifier ;
Voiture V;
GtkWidget *output ;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
char code[30];

input1=lookup_widget(objet,"entrycode2");
input2=lookup_widget(objet,"entrymarque1");
input3=lookup_widget(objet,"entrydateprise1");
input4=lookup_widget(objet,"entryH1");
input5=lookup_widget(objet,"entrydaterest1");
input6=lookup_widget(objet,"entryHe1");
input7=lookup_widget(objet,"entryprix1");
output=lookup_widget(objet,"labelmsgalerte2");
modifier=create_modifier();
strcpy(V.code,gtk_entry_get_text(GTK_ENTRY (input1)));
strcpy(V.marque,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(V.date_prise,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(V.heure,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(V.date_rest,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(V.heure1,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(V.prix,gtk_entry_get_text(GTK_ENTRY(input7)));

if((strcmp(V.code,"")==0)||(strcmp(V.marque,"")==0)||(strcmp(V.date_prise,"")==0)||(strcmp(V.heure,"")==0)||(strcmp(V.date_rest,"")==0)||(strcmp(V.heure1,"")==0)||(strcmp(V.prix,"")==0))
{
gtk_label_set_text(GTK_LABEL(output),"veuillez remplir toutes les cases");
}
else{
modifier_voiture(V,V.code);
gtk_label_set_text(GTK_LABEL(output),"");
gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_entry_set_text(GTK_ENTRY(input2),"");
gtk_entry_set_text(GTK_ENTRY(input3),"");
gtk_entry_set_text(GTK_ENTRY(input4),"");
gtk_entry_set_text(GTK_ENTRY(input5),"");
gtk_entry_set_text(GTK_ENTRY(input6),"");
gtk_entry_set_text(GTK_ENTRY(input7),"");
gtk_widget_show(modifier);
}
}

void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1,  *fenetre_modifier, *treeview1;
fenetre_modifier=lookup_widget(objet,"fenetre_modifier");
gtk_widget_destroy(fenetre_modifier);
window1=create_window1();
gtk_widget_show(window1);
treeview1=lookup_widget(window1,"treeview1");
afficher_voiture(treeview1);

}



void
on_OK1_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajout ;
ajout=lookup_widget(objet,"ajout");
gtk_widget_destroy(ajout);
}


void
on_OK2_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *modifier ;
modifier=lookup_widget(objet,"modifier");
gtk_widget_destroy(modifier);
}


void
on_OK3_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *supprimer ;
supprimer=lookup_widget(objet,"supprimer");
gtk_widget_destroy(supprimer);
}


void
on_rechercher1_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *input2, *input3, *input4, *input5, *input6, *output ;
GtkWidget *inputcode, *modif;
Voiture V;
char code[30];
FILE *f;

input1=lookup_widget(objet,"entrymarque1");
input2=lookup_widget(objet,"entrydateprise1");
input3=lookup_widget(objet,"entryH1");
input4=lookup_widget(objet,"entrydaterest1");
input5=lookup_widget(objet,"entryHe1");
input6=lookup_widget(objet,"entryprix1");


inputcode=lookup_widget(objet,"entrycode2");
output=lookup_widget(objet,"labelmsgalerte1");
strcpy(code,gtk_entry_get_text(GTK_ENTRY(inputcode)));

if(strcmp(code,"")==0){
gtk_label_set_text(GTK_LABEL(output),"entrer un code svp !!!");
}
else{
if(rechercher_voiture(V,code)==0){
gtk_label_set_text(GTK_LABEL(output),"Le code que vous avez entrez n'existe pas ! essayez une autre fois");
gtk_entry_set_text(GTK_ENTRY(inputcode),"");
gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_entry_set_text(GTK_ENTRY(input2),"");
gtk_entry_set_text(GTK_ENTRY(input3),"");
gtk_entry_set_text(GTK_ENTRY(input4),"");
gtk_entry_set_text(GTK_ENTRY(input5),"");
gtk_entry_set_text(GTK_ENTRY(input6),"");
}
else{
f=fopen("voitures.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %s %s %s",V.code,V.marque,V.date_prise,V.heure,V.date_rest,V.heure1,V.prix)!=EOF){
if(strcmp(V.code,code)==0){ 
gtk_entry_set_text(GTK_ENTRY(input1),V.marque);
gtk_entry_set_text(GTK_ENTRY(input2),V.date_prise);
gtk_entry_set_text(GTK_ENTRY(input3),V.heure);
gtk_entry_set_text(GTK_ENTRY(input4),V.date_rest);
gtk_entry_set_text(GTK_ENTRY(input5),V.heure1);
gtk_entry_set_text(GTK_ENTRY(input6),V.prix);
gtk_label_set_text(GTK_LABEL(output),"");
}	
}
fclose(f);
}
}
}
}

void
on_supprimer1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1,*output,*supprimer;
char code[30];
Voiture V;

input1=lookup_widget(objet,"entrycode3");
output=lookup_widget(objet,"labelmsgalerte3");
supprimer=create_supprimer();

strcpy(code,gtk_entry_get_text(GTK_ENTRY(input1)));

if(strcmp(code,"")==0){
gtk_label_set_text(GTK_LABEL(output),"entrer un code svp !!");
}
else{
if(rechercher_voiture(V,code)!=0){
supprimer_voiture(V,code);
gtk_entry_set_text(GTK_ENTRY(input1),"");
gtk_label_set_text(GTK_LABEL(output),"");
gtk_widget_show(supprimer);
}
else{
gtk_label_set_text(GTK_LABEL(output),"voiture inexistante");
}
}
}


void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1,  *fenetre_supprimer, *treeview1;
fenetre_supprimer=lookup_widget(objet,"fenetre_supprimer");
gtk_widget_destroy(fenetre_supprimer);
window1=create_window1();
gtk_widget_show(window1);
treeview1=lookup_widget(window1,"treeview1");
afficher_voiture(treeview1);

}




void
on_retour3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1,  *window0 ;
window1=lookup_widget(objet,"window1");
gtk_widget_destroy(window1);
window0=create_window0();
gtk_widget_show(window0);
}


void
on_retour3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_rechercher1_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_OK1_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_OK2_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_OK3_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_supprimer1_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_retour2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}

