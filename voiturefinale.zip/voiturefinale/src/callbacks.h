#include <gtk/gtk.h>


void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_listevoitures_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_quitter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_checkbutton1_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_OK1_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_OK2_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_OK3_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercher1_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_supprimer1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_retour3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_rechercher1_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_OK1_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_OK2_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_OK3_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer1_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
