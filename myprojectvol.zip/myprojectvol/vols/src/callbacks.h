#include <gtk/gtk.h>


void
on_buttonAjoutervol_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifiervol_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonSupprimervol_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonvalider_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonvalidermodi_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonafficher_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretour_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_calendar1_day_selected              (GtkCalendar     *calendar,
                                        gpointer         user_data);

void
on_buttonok_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
